## LIBRARIES

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score

# read the entire content of the text file
with open('B22AI001_train.txt', 'r') as file:
    content = file.readlines()

# extract column names from the first line
# Parse the remaining content into rows of data
rows = [line.strip().split() for line in content[1:]]
column_names = ['Column' + str(i) for i in range(1, 6)]

# Create DataFrame from parsed rows with column names
train_data= pd.DataFrame(rows, columns=column_names)

# Print the DataFrame
# print(train_data)

X_train=train_data.drop(columns=['Column5'])
y_train=train_data['Column5']
# print(X_train.head())
# print(y_train.head())
# Drop the first row of y_train

# y_train = y_train.iloc[1:]
# Rename the y_train Series to 'Column5'
# y_train = y_train.rename('Column5')

# normalize data

scaler = MinMaxScaler()
X_train_normalized = scaler.fit_transform(X_train)
# X_test_normalized = scaler.fit_transform(X_test)
y_train_reshaped = y_train.to_numpy().reshape(-1, 1)
# print(X_train_normalized)
# print(y_train_reshaped)
## Perceptron Learning Algorithm

class Perceptron:
    def __init__(self, num_features, learning_rate=0.01):
        self.weights_array = np.zeros(num_features+1)
        # self.bias = np.random.rand()
        self.learning_rate = learning_rate

    def predict(self, x):
        # Add bias term
        x = np.insert(x, 0,-1)
        activation = np.dot(self.weights_array, x)
        # print(activation)
        return 1 if activation >= 0 else 0

    def train(self, X, y):
        num_samples,num_features=X.shape
        converge= False
        # iteration=0
        while not converge:
            converge=True
            for i in range(num_samples):
                prediction = self.predict(X[i])
                y_i = int(y[i])  # Cast y[i] to integer
                
                if prediction != y_i:
                
                    
                    x = np.insert(X[i], 0,-1)  # Add bias term
                    
                    if y_i == 1:
                      self.weights_array += x
                    #   print(self.weights_array)
                    else:
                      self.weights_array -= x
                    #   print(self.weights_array)
                    # converge=False    

        print(self.weights_array)    


perceptron = Perceptron(num_features=4)
perceptron.train(X_train_normalized, y_train_reshaped)


## Accuracy

def calculate_accuracy(model, X, y):
    correct_predictions = 0
    num_samples,num_features=X.shape
    for i in range(num_samples):

        prediction = perceptron.predict(X[i])
        y_i=int(y[i])
        if prediction == y_i:
            correct_predictions += 1

    accuracy = correct_predictions / len(X)
    return accuracy


train_accuracy = calculate_accuracy(perceptron, X_train_normalized, y_train_reshaped)

# print(f'TRAIN ACCURACY: {train_accuracy}')


def accuracy_score(y,y_pred):
    num_correct=np.sum(y==y_pred)

    total=len(y_pred)

    accuracy=num_correct/total
    return accuracy

np.savetxt('weights.txt', perceptron.weights_array, fmt='%f')

