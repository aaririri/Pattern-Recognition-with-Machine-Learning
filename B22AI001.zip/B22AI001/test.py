## LIBRARIES

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score

# Load perceptron weights from file
perceptron_weights = np.loadtxt('weights.txt')
X_test = np.loadtxt('B22AI001_test.txt')

scaler = MinMaxScaler()
X_test_normalized = scaler.fit_transform(X_test)


class Perceptron:
    def __init__(self, num_features, learning_rate=0.01):
        self.weights_array = np.zeros(num_features+1)
        # self.bias = np.random.rand()
        self.learning_rate = learning_rate

    def predict(self, x):
        # Add bias term
        x = np.insert(x, 0,-1)
        activation = np.dot(self.weights_array, x)
        # print(activation)
        return 1 if activation >= 0 else 0

    def train(self, X, y):
        num_samples,num_features=X.shape
        converge= False
        # iteration=0
        while not converge:
            converge=True
            for i in range(num_samples):
                prediction = self.predict(X[i])
                y_i = int(y[i])  # Cast y[i] to integer
                
                if prediction != y_i:
                
                    # converge=False
                    x = np.insert(X[i], 0,-1)  # Add bias term
                    
                    if y_i == 1:
                      self.weights_array += x
                    #   print(self.weights_array)
                    else:
                      self.weights_array -= x
                    #   print(self.weights_array)
                    # converge=False       

# Create a new Perceptron instance and set its weights
perceptron = Perceptron(num_features=4)
perceptron.weights_array = perceptron_weights



## Accuracy

def calculate_accuracy(model, X, y):
    correct_predictions = 0
    num_samples,num_features=X.shape
    for i in range(num_samples):

        prediction = perceptron.predict(X[i])

        if prediction == y[i]:
            correct_predictions += 1

    accuracy = correct_predictions / len(X)
    return accuracy


# train_accuracy = calculate_accuracy(perceptron, X_train_normalized, y_train_reshaped)
# test_accuracy=calculate_accuracy(perceptron, X_test_normalized,y_test_reshaped)
# print(train_accuracy)
# print(test_accuracy)

def accuracy_score(y,y_pred):
    num_correct=np.sum(y==y_pred)

    total=len(y_pred)

    accuracy=num_correct/total
    return accuracy


y_pred = [perceptron.predict(x) for x in X_test_normalized]

print(y_pred)